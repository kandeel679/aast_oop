
public class address {
	private String city;
	private String street;
	private String building;
	private String num;
	public address() {
	
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getBuilding() {
		return building;
	}
	public void setBuilding(String building) {
		this.building = building;
	}
	public String getNum() {
		return num;
	}
	public void setNum(String num) {
		this.num = num;
	}
	@Override
	public String toString() {
		return "address [city=" + city + ", street=" + street + ", building=" + building + ", num=" + num + "]";
	}
	
	
	
	

}
