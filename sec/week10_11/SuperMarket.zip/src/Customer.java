import java.util.ArrayList;

public class Customer {
	private String name;
	private address a1;
	private ArrayList<Order> orders = new ArrayList<>();
    
	public Customer(String name , address a1) {
		this.name=name;
		this.a1=a1;
	}
	public void addOrder(Order o) {
		orders.add(o);
	}
	public double GetTotalInnvoice() {
		double total=0;
		for(Order o : orders) {
			if(!o.IsCancelled())
				total+=o.getTotalPrice();
		}
		return total;
	}
	
	public void RemoveOrder (int index) {
		Order o = orders.get(index);
		if(orders.contains(o))
			orders.remove(o);
	}
	public int GetNumOrders() {
		return orders.size();
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public address getA1() {
		return a1;
	}
	public void setA1(address a1) {
		this.a1 = a1;
	}
	@Override
	public String toString() {
		return "Customer [name=" + name + ", a1=" + a1 + ", orders=" + orders + "]";
	}
	
	
}
