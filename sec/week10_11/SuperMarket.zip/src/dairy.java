import java.time.LocalDate;

public class dairy extends Item {
private String brandname;
private LocalDate expiryDate;
	public dairy(String name, double price,String brandname,
			LocalDate expiryDate) {
		super(name, price);
		this.brandname=brandname;
		this.expiryDate=expiryDate;	
	}
	public String getBrandname() {
		return brandname;
	}
	public void setBrandname(String brandname) {
		this.brandname = brandname;
	}
	public LocalDate getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(LocalDate expiryDate) {
		this.expiryDate = expiryDate;
	}
	@Override
	public String toString() {
		return super.toString()+"dairy [brandname=" + brandname + 
				", expiryDate=" + expiryDate + "]";
	}
	

}
