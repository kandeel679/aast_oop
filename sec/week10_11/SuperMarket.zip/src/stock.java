import java.util.ArrayList;

public class stock {
	private ArrayList<Item> items = new ArrayList<>();
	
	public void AddItem(Item i) {
		items.add(i);
	}
	public void RemoveItem(Item i) {
		if(items.contains(i))
		   items.remove(i);
	}
	public Item getItem (int index) {
		return items.get(index);
	}
	@Override
	public String toString() {
		return "stock [items=" + items + "]";
	}
	
	
	
	

}
