import java.util.ArrayList;
import java.util.Date;

public class Order {
	
	private int id;
	private static int counter=1;
	private Date OrderDate;
	private Customer c;
	private ArrayList<Item> items = new ArrayList<>();
	private ArrayList<Double> quantity=new ArrayList<>();
	private static double deliveryfee=20;
	private boolean freeDelivery=false;
	private boolean cancelled=false;
	
	public Order(Customer c) {
		id=counter;
		counter++;
		OrderDate=new Date();
		this.c=c;
	}
	public void addItem(Item i , double q) {
		items.add(i);
		quantity.add(q);
	}
	public void removeItem(int index) {
		Item i = items.get(index);
		if(items.contains(i)) {
			items.remove(i);
			quantity.remove(index);
		}	
	}
	public void RemoveAll() {
		items.clear();
	}
	
	public double getTotalPrice() {
		double total=0;
		for(int i=0;i<items.size();i++) {
			total+=items.get(i).getPrice()*quantity.get(i);
		}
		if(total>=500) {
			freeDelivery=true;
		}
		else
			total+=deliveryfee;
		return total; 
		
	}
	public static double getDeliveryfee() {
		return deliveryfee;
	}
	public static void setDeliveryfee(double deliveryfee) {
		Order.deliveryfee = deliveryfee;
	}
	public void setCancelled(boolean cancelled) {
		this.cancelled = cancelled;
	}
	public boolean IsCancelled() {
		return cancelled;
	}
	public String toString() {
		String s= "order id = "+id+"\n order date = "
	+OrderDate+"\n" +c.toString() +"\n items : \n";
		for(int i =0 ; i<items.size();i++) {
			s+=items.get(i)+" Quantity:"+quantity.get(i)
			+"\n";
		}
		s+="Delivery= "+deliveryfee;
		if(freeDelivery)
			s+="\n Delivery discount = - "+deliveryfee;
		return s;
	}
	

}
